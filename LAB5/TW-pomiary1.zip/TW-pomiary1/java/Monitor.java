public interface Monitor {
    int getRandomNumber(int min, int max);
    void produce();
    void consume();
}
